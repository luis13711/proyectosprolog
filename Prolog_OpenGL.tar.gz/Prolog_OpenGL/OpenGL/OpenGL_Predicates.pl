:- load_foreign_library('OpenGL.so').

eq(X,X).

gl_glFlush:-    c_glFlush.

gl_glVertex2i(X,Y):-

    integer(X),
    integer(Y),
    c_glVertex2i(X,Y).

gl_glColor3f(Red,Green,Blue):-

    float(Red),
    float(Green),
    float(Blue),
    c_glColor3f(Red,Green,Blue).

gl_glBegin(Mode):-

    Mode_Eval is Mode,
    c_glBegin(Mode_Eval).

gl_glScalef(XScale,YScale,ZScale):-
    
    float(XScale),
    float(YScale),
    float(ZScale),
    c_glScalef(XScale,YScale,ZScale).

gl_glOrtho(Left,Right,Bottom,Top,Near,Far):-

    float(Left),
    float(Right),
    float(Bottom),
    float(Top),
    float(Near),
    float(Far),
    c_glOrtho(Left,Right,Bottom,Top,Near,Far).

gl_glLoadIdentity:-
    c_glLoadIdentity.

gl_glViewport(X,Y,Width,Height):-
    c_glViewport(X,Y,Width,Height).

%P% gl_glClear(OptionList).
gl_glClear(OptionList):-
	Applied_options is OptionList,
	c_glClear(Applied_options).

%P% gl_glCallList(Index).
gl_glCallList(Index):-	c_glCallList(Index).

%P% glut_glutSwapBuffers.
glut_glutSwapBuffers:- c_glutSwapBuffers.

%P% glu_gluNewQuadric(PL_GluQuadricPtr).
glu_gluNewQuadric(PL_GluQuadricPtr):-
    c_gluNewQuadric(PL_GluQuadricPtr),
    write('Prolog reports address as '),write_ln(PL_GluQuadricPtr).

%P% glu_gluQuadricDrawStyle(PL_GluQuadricPtr,OptionList).
glu_gluQuadricDrawStyle(PL_GluQuadricPtr,OptionList):-
	AppliedList is OptionList,
       	c_gluQuadricDrawStyle(PL_GluQuadricPtr,AppliedList).

%P% gl_glNewList(DisplayListIndex,OptionList).
gl_glNewList(DisplayListIndex,OptionList):-
	integer(DisplayListIndex),
	AppliedList is OptionList,
	c_glNewList(DisplayListIndex,AppliedList).

%P% glu_gluSphere(PL_GluQuadricPtr,Radius,Slices,Stacks).
glu_gluSphere(PL_GluQuadricPtr,Radius,Slices,Stacks):-
	integer(Stacks),
	integer(Slices),
	float(Radius),
	c_gluSphere(PL_GluQuadricPtr,Radius,Slices,Stacks).

%P% gl_glEndList.
gl_glEndList:- c_glEndList.

gl_glLightfv(GL_Light,Params,PL_ParamValueList):-
	eq(PL_ParamValueList, [A,B,C,D]),
	((float(A),
	 float(B),
	 float(C),
	 float(D));
	(integer(A),
	 integer(B),
	 integer(C),
	 integer(D))),
	Light is GL_Light,
	ParamApplied is Params,
	c_glLightfv(Light,ParamApplied,A,B,C,D).

%P% gl_glEnable(GL_DEFN).
gl_glEnable(GL_DEFN):-
	Option is GL_DEFN,
	c_glEnable(Option).

%P% gl_glMatrixMode(GL_MODE).
gl_glMatrixMode(GL_MODE):-
	Mode is GL_MODE,
	c_glMatrixMode(Mode).

%P% glu_gluPerspective(FovY,Aspect,ZNear,ZFar).
glu_gluPerspective(FovY,Aspect,ZNear,ZFar):-
	float(FovY),
	float(Aspect),
	float(ZNear),
	float(ZFar),
	c_gluPerspective(FovY,Aspect,ZNear,ZFar).

%P% glu_gluLookAt(EyeX,EyeY,EyeZ,CenterX,CenterY,CenterZ,UpX,UpY,Upz).
glu_gluLookAt(EyeX,EyeY,EyeZ,
	     CenterX,CenterY,CenterZ,
	     UpX,UpY,Upz):-
	forall(member(Param,[EyeX,EyeY,EyeZ,
	     CenterX,CenterY,CenterZ,
	     UpX,UpY,Upz]),
	float(Param)),
	c_gluLookAt(EyeX,EyeY,EyeZ,
	     CenterX,CenterY,CenterZ,
	     UpX,UpY,Upz).

%P% gl_glTranslatef(X,Y,Z).
gl_glTranslatef(X,Y,Z):-
	float(X),
	float(Y),
	float(Z),
	c_glTranslatef(X,Y,Z).

%P% glut_glutInit.
glut_glutInit:-	c_glutInit.

%P% glut_glutInitDisplayMode(OptionList)
glut_glutInitDisplayMode(OptionList):-
	AppliedOptions is OptionList,
	c_glutInitDisplayMode(AppliedOptions).

%P% glut_glutCreateWindow(String)
glut_glutCreateWindow(String):-
	c_glutCreateWindow(String).

%P% glut_glutDisplayFunc(Prolog_Predicate_Head).
glut_glutDisplayFunc:- write_ln('glutDisplayFunc has been set to call user:glut_display_function/0'),
    c_glutDisplayFunc.

%P% glut_glutReshapeFunc.
glut_glutReshapeFunc:- 
    write_ln('glutReshapeFunc has been set to call user:glut_reshape_function/0'),
    c_glutReshapeFunc.

%P% glut_glutMainLoop.
glut_glutMainLoop:-

    c_glutMainLoop.
