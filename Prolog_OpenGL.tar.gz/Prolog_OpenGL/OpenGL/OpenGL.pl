:-
	['OpenGL_defs.pl'],
        ['OpenGL_Predicates.pl'].
