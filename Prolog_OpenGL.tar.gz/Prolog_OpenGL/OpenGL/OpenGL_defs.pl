:-
	['OpenGL_gl_defs.pl'],
	['OpenGL_glu_defs.pl'],
	['OpenGL_glut_defs.pl'].
