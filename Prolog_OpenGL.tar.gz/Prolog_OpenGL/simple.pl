:- ['OpenGL/OpenGL.pl'].


% To provide the (re)display and (re)shape functions, one normally
% provides a C function. Trivially, this is replaced with the predicates
% glut_reshape_function/0 and glut_display_function.

glut_reshape_function:- glut_reshape_function(simple).
glut_reshape_function(simple):-
    X is 0,
    Y is 0,
    W is 300,
    H is 300,
    gl_glViewport(X,Y,W,H),
    write('viewport in prolog is '),write_ln([0,0,W,H]),
    gl_glMatrixMode(gl_GL_PROJECTION),
    gl_glLoadIdentity,
    gl_glOrtho(0,W,0,H,-1,1),
    gl_glScalef(1,-1,1),
    gl_glTranslatef(0,-H,0).

go:-

	% initialise, create a window and put a sphere in it. Then duplicate window.
	
    glut_glutInit,
    glut_glutInitDisplayMode( glut_GLUT_DOUBLE \/ glut_GLUT_RGB \/ glut_GLUT_DEPTH),
    glut_glutCreateWindow('sphere'),
    glut_glutDisplayFunc,
    gfxinit,
    glut_glutCreateWindow('a second window'),
    glut_glutDisplayFunc,
    gfxinit,
    glut_glutMainLoop.

gfxinit:-

    glu_gluNewQuadric(QuadricPtr),
    glu_gluQuadricDrawStyle(QuadricPtr,glu_GLU_FILL),
    gl_glNewList(1,gl_GL_COMPILE),
    glu_gluSphere(QuadricPtr,1.0,20,20),
    gl_glEndList,
    gl_glLightfv(gl_GL_LIGHT0,gl_GL_DIFFUSE,[1.0,0.0,0.0,1.0]),
    gl_glLightfv(gl_GL_LIGHT0,gl_GL_POSITION,[1.0,1.0,1.0,0.0]),
    gl_glEnable(gl_GL_LIGHTING),
    gl_glEnable(gl_GL_LIGHT0),
    gl_glEnable(gl_GL_DEPTH_TEST),
    gl_glMatrixMode(gl_GL_PROJECTION),
    glu_gluPerspective(40.0,1.0,1.0,10.0),
    gl_glMatrixMode(gl_GL_MODELVIEW),
    glu_gluLookAt(0.0,0.0,5.0,
		  0.0,0.0,0.0,
		  0.0,1.0,0.0),
    gl_glTranslatef(0.0,0.0,-1.0).

glut_display_function:- glut_display_function(sphere2).
glut_display_function(sphere2):-

    write('Call to Display Function'),
    gl_glClear(gl_GL_COLOR_BUFFER_BIT \/ gl_GL_DEPTH_BUFFER_BIT),
    gl_glCallList(1),
    glut_glutSwapBuffers.


